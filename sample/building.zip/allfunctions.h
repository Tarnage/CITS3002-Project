extern int	square(int);
extern int	cube(int);
