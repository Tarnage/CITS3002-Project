#ifndef STRSPLIT_H
#define STRSPLIT_H

extern char **strsplit(char *, int *);
extern void free_words(char **);

#endif
